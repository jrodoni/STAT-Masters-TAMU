
# goflogisticmle.R
# The following program computes the K-S Statistics 
# for testing goodness of the fit of a Logistic Distribution 
# with unspecified parameters. The MLE's are computed. 
# The K-S statistics is an approximation due to using the MLE's in place of
# known values of the parameters

 x = c(16.20,9.37,25.80,9.55,12.86,15.34,18.08,10.76,14.92,9.75,17.10,13.97,
15.08,9.24,11.99,13.60,8.16,12.82,12.89,13.59,16.23,14.19,9.03,9.58,13.68)


#obtain MLE of the a=location and b=scale parameters in logistic model

library(MASS)


mleestD = coef(fitdistr(x,"logistic"))
aD = mleestD[1]
bD = mleestD[2]

n = length(x)

x = sort(x)
i= 1:n

# Approximate K-S GOF Test for Logistic Model

ks.test(x,"plogis",aD,bD)


ui= (i-.5)/n
QLog= log(ui/(1-ui))
plot(QLog,x,abline(lm(x~QLog)),
       main="Logistic Reference Plot",cex=.75,lab=c(7,11,7),
       xlab=expression(Q(u[i]) == log(u[i]/(1-u[i]))),
       ylab=expression(y == X[(i)]))
legend(-3.5,24,expression(y == 13.35 + 2.036*Q(u)))
legend(-3.5,22,"KS = .124, p-value>.25")
 
