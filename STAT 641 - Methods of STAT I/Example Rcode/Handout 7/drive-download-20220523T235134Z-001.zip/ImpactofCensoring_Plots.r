
x <- seq(0,3500,.1)
D1 <- dweibull(y,2.1103,1537.2333)
D2 <- dweibull(y,2.5966,1472.6650)
D3 <- dweibull(y,3.0409,1314.0159)
D <- cbind(D1,D2,D3)


matplot(x,D,type="l",ylab="f(y)", xlab="y",lab=c(18,10,7),col=c(1,1,1),lwd=1.8,lty=c(1,2,3))
title("Weibull Density Functions-For Three MLEs")
#par(font=5)

text(1820,8e-04,"DeletedData",adj=0)
arrows(1800,8e-04,1400,8e-04)

text(2220,5e-04,"CensoredData",adj=0)
arrows(2200,5e-04,1760,5e-04)

text(2620,2.5e-04,"OriginalData",adj=0)
arrows(2600,2.5e-04,2200,2.5e-04)

abline(h=0)